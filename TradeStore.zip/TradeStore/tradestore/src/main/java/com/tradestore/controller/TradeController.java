package com.tradestore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tradestore.exception.InvalidTradeException;
import com.tradestore.model.Trade;
import com.tradestore.service.TradeService;

@RestController
public class TradeController {
	
	@Autowired
	private TradeService tradeService;
	
	@PostMapping(value="/trade",consumes = MediaType.APPLICATION_JSON_VALUE,
	        produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> tradeValidateStore(@RequestBody Trade trade){
		 if(tradeService.isValidTrade(trade)) {
		    tradeService.persist(trade);
		 }else {
			// return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
	         throw new InvalidTradeException(trade.getTradeId());
		 }
		
		return ResponseEntity.status(HttpStatus.OK).build();
		
	}
	

    @GetMapping("/trade")
    public List<Trade> findAllTrades(){
        return tradeService.findAll();
    }
	

}
